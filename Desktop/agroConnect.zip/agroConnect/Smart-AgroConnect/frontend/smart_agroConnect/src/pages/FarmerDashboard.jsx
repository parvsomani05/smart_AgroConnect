import React from "react";

const FarmerDashboard = () => {
  return (
    <div className="container mt-4">
      <h1 className="display-4">Farmer Dashboard</h1>
      <p className="lead">Welcome to the Farmer Dashboard!</p>
    </div>
  );
};

export default FarmerDashboard;
