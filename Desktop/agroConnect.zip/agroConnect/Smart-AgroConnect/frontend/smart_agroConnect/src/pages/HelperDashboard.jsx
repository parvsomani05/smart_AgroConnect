import React from "react";

const HelperDashboard = () => {
  return (
    <div className="container mt-4">
      <h1 className="display-4">Helper Dashboard</h1>
      <p className="lead">Welcome to the Helper Dashboard!</p>
    </div>
  );
};

export default HelperDashboard;
