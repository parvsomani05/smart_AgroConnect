import React from "react";

const BuyerDashboard = () => {
  return (
    <div className="container mt-4">
      <h1 className="display-4">Buyer Dashboard</h1>
      <p className="lead">Welcome to the Buyer Dashboard!</p>
    </div>
  );
};

export default BuyerDashboard;
