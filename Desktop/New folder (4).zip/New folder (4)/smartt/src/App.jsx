import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./assets/Home";  // Updated import path
import Registration from "./Farmar/Registration";

import OTPLogin from "./Farmar/Otplogin";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/registration" element={<Registration/>} />
        <Route path="/login" element={<OTPLogin/>} />
      </Routes>
    </Router>
  );
}

export default App;
