
import { initializeApp } from "firebase/app";
import {getAuth} from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCq9STDnGTVNbj4jd4Cb9PXRl3064xjcPE",
  authDomain: "smarti-95073.firebaseapp.com",
  projectId: "smarti-95073",
  storageBucket: "smarti-95073.firebasestorage.app",
  messagingSenderId: "184830285551",
  appId: "1:184830285551:web:671cd490116ada71d06d1a"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);