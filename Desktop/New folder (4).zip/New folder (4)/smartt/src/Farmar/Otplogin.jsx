import { useState } from "react";
import { auth } from "../firebase"; // Adjust the path based on your project structure
import { RecaptchaVerifier, signInWithPhoneNumber } from "firebase/auth";
import PhoneInput from "react-phone-number-input";
import "react-phone-number-input/style.css";
import { useNavigate } from "react-router-dom"; // ✅ Import useNavigate
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";

export default function OtpLogin() {
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [confirmationResult, setConfirmationResult] = useState(null);
  const [message, setMessage] = useState("");
  const navigate = useNavigate(); // ✅ Initialize navigate function

  // Initialize reCAPTCHA
  const setupRecaptcha = () => {
    if (!window.recaptchaVerifier) {
      window.recaptchaVerifier = new RecaptchaVerifier(auth, "recaptcha-container", {
        size: "invisible",
      });
    }
  };

  // Send OTP
  const sendOtp = async () => {
    if (!phone || phone.length < 10) {
      setMessage("Please enter a valid phone number.");
      return;
    }

    try {
      setupRecaptcha(); // ✅ Ensure reCAPTCHA is setup before sending OTP
      const appVerifier = window.recaptchaVerifier;

      const confirmation = await signInWithPhoneNumber(auth, phone, appVerifier);
      setConfirmationResult(confirmation);
      setMessage("OTP sent successfully.");
      console.log("OTP sent to:", phone);
    } catch (error) {
      console.error("Error sending OTP:", error.message);
      setMessage(error.message);
    }
  };

  // Verify OTP
  const verifyOtp = async () => {
    if (!otp) {
      setMessage("Please enter OTP.");
      return;
    }

    try {
      const result = await confirmationResult.confirm(otp);
      setMessage("OTP verified! Login successful.");

      // ✅ Check if user is new or existing
      if (result.additionalUserInfo?.isNewUser) {
        navigate("/signup"); // Redirect new user to sign-up page
      } else {
        navigate("/home"); // Redirect existing user to home page
      }
    } catch (error) {
      console.error("Error verifying OTP:", error);
      setMessage("Invalid OTP. Try again.");
    }
  };

  return (
    <div>
      <Navbar />
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-6">
        <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
          <h2 className="text-2xl font-bold text-center text-green-600 mb-4">Login with OTP</h2>
          <PhoneInput
            defaultCountry="IN"
            value={phone}
            onChange={setPhone}
            className="w-full border p-3 rounded-lg mb-4"
          />
          <button onClick={sendOtp} className="w-full bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600 transition">
            Send OTP
          </button>

          {confirmationResult && (
            <div className="mt-4">
              <input
                type="text"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                placeholder="Enter OTP"
                className="w-full border p-3 rounded-lg mb-4"
              />
              <button onClick={verifyOtp} className="w-full bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition">
                Verify OTP
              </button>
            </div>
          )}

          <p className="text-center text-red-500 mt-4">{message}</p>
          <div id="recaptcha-container"></div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
