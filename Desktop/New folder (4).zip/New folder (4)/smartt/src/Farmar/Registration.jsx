import { useState } from "react";
import { useTranslation } from "react-i18next";

import { motion } from "framer-motion";
import { FaUser, FaShoppingCart } from "react-icons/fa";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";

export default function Registration() {
  const { t } = useTranslation();
  const [userType, setUserType] = useState("farmer");

  return (
    <div>
   <Navbar/>
      <div className="flex justify-center items-center min-h-screen bg-gray-100 p-6">
        <motion.div 
          initial={{ opacity: 0, y: -50 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.5 }}
          className="bg-white p-10 rounded-2xl shadow-xl w-full max-w-3xl"
        >
          <h2 className="text-3xl font-bold text-center text-green-600 mb-6">{t("registrationTitle")}</h2>
          <p className="text-center text-gray-500 mb-8">{t("selectProfileType")}</p>

          <div className="flex justify-center gap-6 mb-8">
            <button
              className={`flex items-center gap-2 px-6 py-3 rounded-xl border-2 transition-all duration-300 ${
                userType === "farmer" ? "bg-green-500 text-white border-green-500" : "bg-gray-200 border-gray-300"
              }`}
              onClick={() => setUserType("farmer")}
            >
              <FaUser /> {t("farmer")}
            </button>
            <button
              className={`flex items-center gap-2 px-6 py-3 rounded-xl border-2 transition-all duration-300 ${
                userType === "buyer" ? "bg-blue-500 text-white border-blue-500" : "bg-gray-200 border-gray-300"
              }`}
              onClick={() => setUserType("buyer")}
            >
              <FaShoppingCart /> {t("buyer")}
            </button>
          </div>

          <form className="grid grid-cols-2 gap-6">
            <input className="p-3 border rounded-xl shadow-sm" type="text" placeholder={t("yourName")} required />
            <input className="p-3 border rounded-xl shadow-sm" type="email" placeholder={t("emailId")} required />
            <input className="p-3 border rounded-xl shadow-sm" type="text" placeholder={t("pinCode")} required />
            <input className="p-3 border rounded-xl shadow-sm" type="text" placeholder={t("yourAddress")} />
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="col-span-2 bg-red-500 text-white py-3 rounded-xl hover:bg-red-600 shadow-md transition-all"
            >
              {t("continue")}
            </motion.button>
          </form>
        </motion.div>
      </div>
      <Footer/>
    </div>
    
  );
}
