export default function Footer() {
    return (
      <footer className="bg-gray-800 text-white text-center py-5 mt-10">
        <p>&copy; 2025 Smart AgroConnect. All rights reserved.</p>
      </footer>
    );
  }
  