import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";

export default function Navbar() {
  const { t, i18n } = useTranslation();

  const changeLanguage = (event) => {
    const selectedLang = event.target.value;
    i18n.changeLanguage(selectedLang); // Change language globally
  };

  return (
    <nav className="bg-white shadow-md p-4 flex justify-between items-center">
      <h1 className="text-2xl font-bold text-green-600">{t("title")}</h1>
      <div>
        <Link to="/" className="mx-3 text-blue-600 hover:underline">{t("home")}</Link>
        <Link to="/registration" className="mx-3 text-blue-600 hover:underline">{t("registration")}</Link>
        <Link to="/login" className="mx-3 text-blue-600 hover:underline">{t("login")}</Link>
      </div>
      <select
        onChange={changeLanguage}
        className="border p-1 rounded-md"
      >
        <option value="en">English</option>
        <option value="hi">हिन्दी</option>
        <option value="gu">ગુજરાતી</option>
      </select>
    </nav>
  );
}
