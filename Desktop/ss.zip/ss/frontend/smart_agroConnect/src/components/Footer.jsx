import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-dark text-light py-4">
      <div className="container text-center">
        <div className="row">
          {/* Left Section */}
          <div className="col-md-4 mb-3">
            <h5>Smart AgroConnect</h5>
            <p>Connecting farmers and buyers for a better agricultural future.</p>
          </div>

          {/* Center Section */}
          <div className="col-md-4 mb-3">
            <h5>Quick Links</h5>
            <ul className="list-unstyled">
              <li><a href="/about" className="text-light text-decoration-none">About Us</a></li>
              <li><a href="/contact" className="text-light text-decoration-none">Contact</a></li>
              <li><a href="/privacy" className="text-light text-decoration-none">Privacy Policy</a></li>
              <li><a href="/terms" className="text-light text-decoration-none">Terms of Service</a></li>
            </ul>
          </div>

          {/* Right Section - Social Media */}
          <div className="col-md-4">
            <h5>Follow Us</h5>
            <div className="d-flex justify-content-center gap-3">
              <a href="https://facebook.com" className="text-light fs-4"><FaFacebook /></a>
              <a href="https://twitter.com" className="text-light fs-4"><FaTwitter /></a>
              <a href="https://instagram.com" className="text-light fs-4"><FaInstagram /></a>
              <a href="https://linkedin.com" className="text-light fs-4"><FaLinkedin /></a>
            </div>
          </div>
        </div>

        {/* Copyright Section */}
        <div className="mt-3">
          <p className="mb-0">&copy; {new Date().getFullYear()} Smart AgroConnect. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
