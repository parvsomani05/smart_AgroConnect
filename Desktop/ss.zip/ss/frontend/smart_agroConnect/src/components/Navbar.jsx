import React from "react";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

const Navbar = () => {
  return (
    <nav
      className="navbar navbar-expand-lg navbar-light"
      style={{
        backgroundColor: "#ABC8C7",
        animation: "fadeIn 1s ease-in-out",
      }}
    >
      <div className="container-fluid">
        <Link to="/" className="navbar-brand fw-bold text-black">
          Smart AgroConnect
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link to="/login" className="nav-link text-black animated-underline">
                Login
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/register" className="nav-link text-black animated-underline">
                Register
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <style>
        {`
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
          }

          .animated-underline {
            position: relative;
            text-decoration: none;
          }

          .animated-underline::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: -2px;
            width: 0;
            height: 2px;
            background-color: white;
            transition: width 0.4s ease-in-out;
          }

          .animated-underline:hover::after {
            width: 100%;
          }
        `}
      </style>
    </nav>
  );
};

export default Navbar;
