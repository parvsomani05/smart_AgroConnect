import React, { useEffect, useState } from "react";
import axios from "axios";
import { FaUsers, FaBox, FaGavel, FaBars } from "react-icons/fa";
import { Bar } from "react-chartjs-2";
import "bootstrap/dist/css/bootstrap.min.css";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const AdminDashboard = () => {
  const [farmers, setFarmers] = useState([]);
  const [buyers, setBuyers] = useState([]);
  const [helpers, setHelpers] = useState([]);
  const [revenue, setRevenue] = useState(0);
  const [farmerRequests, setFarmerRequests] = useState([]);
  const [buyerRequests, setBuyerRequests] = useState([]);
  const [helperRequests, setHelperRequests] = useState([]);
  const [activeSection, setActiveSection] = useState("dashboard");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const farmersResponse = await axios.get("http://localhost:5000/api/admin/farmers");
        const buyersResponse = await axios.get("http://localhost:5000/api/admin/buyers");
        const helpersResponse = await axios.get("http://localhost:5000/api/admin/helpers");
        const revenueResponse = await axios.get("http://localhost:5000/api/admin/revenue");
        const farmerReqResponse = await axios.get("http://localhost:5000/api/admin/farmer-requests");
        const buyerReqResponse = await axios.get("http://localhost:5000/api/admin/buyer-requests");
        const helperReqResponse = await axios.get("http://localhost:5000/api/admin/helper-requests");

        setFarmers(farmersResponse.data);
        setBuyers(buyersResponse.data);
        setHelpers(helpersResponse.data);
        setRevenue(revenueResponse.data);
        setFarmerRequests(farmerReqResponse.data);
        setBuyerRequests(buyerReqResponse.data);
        setHelperRequests(helperReqResponse.data);
      } catch (error) {
        console.error("Error fetching admin data:", error);
      }
    };
    fetchData();
  }, []);

  const chartData = {
    labels: ["Farmers", "Buyers", "Helpers", "Revenue"],
    datasets: [
      {
        label: "Counts",
        data: [farmers.length, buyers.length, helpers.length, revenue],
        backgroundColor: ["#007bff", "#28a745", "#dc3545", "#ffc107"],
      },
    ],
  };

  return (
    <div className="d-flex vh-100">
      {/* Sidebar */}
      <div className="bg-dark text-white p-4 vh-100" style={{ width: "250px" }}>
        <h2 className="mb-4">Admin Panel</h2>
        <button className="btn btn-outline-light w-100 mb-2" onClick={() => setActiveSection("dashboard")}>
          <FaBars /> Dashboard
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-grow-1 p-4 bg-light overflow-auto">
        <h1 className="mb-4">{activeSection.charAt(0).toUpperCase() + activeSection.slice(1)}</h1>
        {activeSection === "dashboard" && (
          <div className="row">
            <div className="col-md-3 mb-3">
              <div className="card text-white bg-primary p-3">
                <h5>Total Farmers</h5>
                <h3>{farmers.length}</h3>
              </div>
            </div>
            <div className="col-md-3 mb-3">
              <div className="card text-white bg-success p-3">
                <h5>Total Buyers</h5>
                <h3>{buyers.length}</h3>
              </div>
            </div>
            <div className="col-md-3 mb-3">
              <div className="card text-white bg-danger p-3">
                <h5>Total Helpers</h5>
                <h3>{helpers.length}</h3>
              </div>
            </div>
            <div className="col-md-3 mb-3">
              <div className="card text-white bg-warning p-3">
                <h5>Total Revenue</h5>
                <h3>RS.{revenue}</h3>
              </div>
            </div>
            <div className="col-md-3 mb-3">
              <div className="card text-white bg-info p-3">
                <h5>Farmer Requests</h5>
                <h3>{farmerRequests.length}</h3>
              </div>
            </div>
            <div className="col-md-3 mb-3">
              <div className="card text-white bg-secondary p-3">
                <h5>Buyer Requests</h5>
                <h3>{buyerRequests.length}</h3>
              </div>
            </div>
            <div className="col-md-3 mb-3">
              <div className="card text-white bg-dark p-3">
                <h5>Helper Requests</h5>
                <h3>{helperRequests.length}</h3>
              </div>
            </div>
          </div>
        )}
        {/* Chart Section */}
        {activeSection === "dashboard" && (
          <div className="card p-4 mt-4">
            <h4>Overview</h4>
            <Bar data={chartData} />
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
