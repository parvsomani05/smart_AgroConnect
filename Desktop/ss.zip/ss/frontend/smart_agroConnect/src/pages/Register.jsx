import React, { useState } from "react";
import axios from "axios";
import { useHistory } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { FaTractor, FaShoppingCart, FaHandsHelping } from "react-icons/fa";

const Register = () => {
  const [role, setRole] = useState("Farmer");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [pincode, setPincode] = useState("");
  const [state, setState] = useState("");
  const [district, setDistrict] = useState("");
  const [taluka, setTaluka] = useState("");
  const [address, setAddress] = useState("");
  const [panCard, setPanCard] = useState("");
  const [cancelledCheque, setCancelledCheque] = useState("");
  const [gstNo, setGstNo] = useState(""); // Buyer only
  const [agricultureCertificate, setAgricultureCertificate] = useState(""); // Helper only
  const history = useHistory();

  //text input validation
  const validateInputs = () => {
    const phoneRegex = /^\d{10}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!phoneRegex.test(phone)) {
      alert("Phone number must be exactly 10 digits.");
      return false;
    }
    if (!emailRegex.test(email)) {
      alert("Please enter a valid email.");
      return false;
    }
    if (password !== confirmPassword) {
      alert("Passwords do not match.");
      return false;
    }
    return true;
  };

  //file uplod validation
  const handleFileUpload = (e, setFile) => {
    const file = e.target.files[0];
    if (file) {
      const validExtensions = ["image/jpeg", "image/png", "application/pdf", "image/jpg"];
      if (!validExtensions.includes(file.type)) {
        alert("Invalid file type. Please upload JPG, PNG, or PDF.");
        return;
      }
      setFile(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateInputs()) return;
    try {
      const { data } = await axios.post("http://localhost:5000/api/auth/register", {
        name, phone, email, password, role, pincode, state, district, taluka,
        address, documents: { panCard, cancelledCheque, gstNo, agricultureCertificate },
      });
      localStorage.setItem("token", data.token);
      if (role === "Farmer") history.push("/farmer-dashboard");
      else if (role === "Buyer") history.push("/buyer-dashboard");
      else if (role === "Helper") history.push("/helper-dashboard");
    } catch (error) {
      console.error("Registration failed:", error);
    }
  };

  return (
    <div className="container mt-4 mb-5">
      <h1 className="text-center mb-4">Register</h1>

      {/* Role Selection with Icons */}
      <div className="d-flex justify-content-center mb-4">
        <div
          className={`mx-3 text-center p-3 border rounded ${role === "Farmer" ? "bg-primary text-white" : "bg-light"}`}
          onClick={() => setRole("Farmer")}
          style={{ cursor: "pointer", width: "100px" }}
        >
          <FaTractor size={40} />
          <p className="mt-2">Farmer</p>
        </div>
        <div
          className={`mx-3 text-center p-3 border rounded ${role === "Buyer" ? "bg-primary text-white" : "bg-light"}`}
          onClick={() => setRole("Buyer")}
          style={{ cursor: "pointer", width: "100px" }}
        >
          <FaShoppingCart size={40} />
          <p className="mt-2">Buyer</p>
        </div>
        <div
          className={`mx-3 text-center p-3 border rounded ${role === "Helper" ? "bg-primary text-white" : "bg-light"}`}
          onClick={() => setRole("Helper")}
          style={{ cursor: "pointer", width: "100px" }}
        >
          <FaHandsHelping size={40} />
          <p className="mt-2">Helper</p>
        </div>
      </div>

      {/* Registration Form */}
      <form onSubmit={handleSubmit} className="p-4 border rounded bg-light">
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input type="text" className="form-control" placeholder="Enter your name" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>

        {/* Phone & Email */}
        <div className="row mb-3">
          <div className="col-md-6">
            <label className="form-label">Phone</label>
            <input type="tel" className="form-control" placeholder="Enter phone number" value={phone} onChange={(e) => setPhone(e.target.value)} required />
          </div>
          <div className="col-md-6">
            <label className="form-label">Email</label>
            <input type="email" className="form-control" placeholder="Enter email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
        </div>

        {/*password confirm password */}
        <div className="row mb-3">
          <div className="col-md-6">
            <label className="form-label">Password</label>
            <input type="password" className="form-control" placeholder="Enter password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <div className="col-md-6">
            <label className="form-label">Confirm Password</label>
            <input type="password" className="form-control" placeholder="Confirm password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
          </div>
        </div>

        {/* Pincode, State, District, Taluka */}
        <div className="row mb-3">
          <div className="col-md-3">
            <label className="form-label">Pincode</label>
            <input type="text" className="form-control" placeholder="Pincode" value={pincode} onChange={(e) => setPincode(e.target.value)} required />
          </div>
          <div className="col-md-3">
            <label className="form-label">State</label>
            <input type="text" className="form-control" placeholder="State" value={state} onChange={(e) => setState(e.target.value)} required />
          </div>
          <div className="col-md-3">
            <label className="form-label">District</label>
            <input type="text" className="form-control" placeholder="District" value={district} onChange={(e) => setDistrict(e.target.value)} required />
          </div>
          <div className="col-md-3">
            <label className="form-label">Taluka</label>
            <input type="text" className="form-control" placeholder="Taluka" value={taluka} onChange={(e) => setTaluka(e.target.value)} required />
          </div>
        </div>

        {/* Address */}
        <div className="mb-3">
          <label className="form-label">Address</label>
          <textarea className="form-control" placeholder="Enter full address" value={address} onChange={(e) => setAddress(e.target.value)} required />
        </div>

        {/* Documents */}
        <div className="row mb-3">
          <div className="col-md-6">
            <label className="form-label">PAN Card</label>
            <input type="file" className="form-control" onChange={(e) => setPanCard(e.target.files[0])} required />
          </div>
          <div className="col-md-6">
            <label className="form-label">Cancelled Cheque</label>
            <input type="file" className="form-control" onChange={(e) => setCancelledCheque(e.target.files[0])} required />
          </div>
        </div>

        {/* Additional Fields Based on Role */}
        {role === "Buyer" && (
          <div className="mb-3">
            <label className="form-label">GST Number</label>
            <input type="text" className="form-control" placeholder="Enter GST Number" value={gstNo} onChange={(e) => setGstNo(e.target.value)} required />
          </div>
        )}
        {role === "Helper" && (
          <div className="mb-3">
            <label className="form-label">Agriculture Certificate</label>
            <input type="file" className="form-control" onChange={(e) => handleFileUpload(e, setAgricultureCertificate)} required />
          </div>
        )}

        {/* Submit Button */}
        <button type="submit" className="btn btn-primary w-100">Register</button>
      </form>
    </div>
  );
};

export default Register;
