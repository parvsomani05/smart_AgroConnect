import java.net.*;
import java.util.Scanner;

public class ChatClient19 {
    public static void main(String[] args) throws Exception {
        DatagramSocket socket = new DatagramSocket();
        InetAddress serverAddress = InetAddress.getByName("localhost");
        Scanner scanner = new Scanner(System.in);

        while (true) {
            // Client message
            System.out.print("Client: ");
            String clientMessage = scanner.nextLine();
            
            // Send message to server
            DatagramPacket sendPacket = new DatagramPacket(clientMessage.getBytes(), clientMessage.length(), serverAddress, 9876);
            socket.send(sendPacket);

            // If client sends "exit", terminate the chat
            if (clientMessage.equalsIgnoreCase("exit")) {
                System.out.println("Client disconnected.");
                break;
            }

            // Receive server's reply
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            socket.receive(receivePacket);
            String serverMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
            System.out.println("Server: " + serverMessage);
        }

        socket.close();
    }
}
