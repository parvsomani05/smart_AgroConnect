// UDP Server
import java.net.*;
import java.io.*;

public class UDPServer14 {
    public static void main(String[] args) throws Exception {
        DatagramSocket serverSocket = new DatagramSocket(9876);
        byte[] receiveData = new byte[1024];
        byte[] sendData;

        while (true) {
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            serverSocket.receive(receivePacket);
            String data = new String(receivePacket.getData(), 0, receivePacket.getLength());
            String[] numbers = data.split(" ");
            int x = Integer.parseInt(numbers[0]);
            int n = Integer.parseInt(numbers[1]);
            
            int result = (int) Math.pow(x, n);
            InetAddress clientAddress = receivePacket.getAddress();
            int clientPort = receivePacket.getPort();
            sendData = String.valueOf(result).getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
            serverSocket.send(sendPacket);
        }
    }
}