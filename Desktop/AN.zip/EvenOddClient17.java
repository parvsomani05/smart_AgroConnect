import java.net.*;
import java.util.Scanner;

public class EvenOddClient17 {
    public static void main(String[] args) throws Exception {
        DatagramSocket socket = new DatagramSocket();
        InetAddress serverAddress = InetAddress.getByName("localhost");
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter an integer to check if it's even or odd: ");
        int number = scanner.nextInt();

        DatagramPacket sendPacket = new DatagramPacket(String.valueOf(number).getBytes(), String.valueOf(number).length(), serverAddress, 9876);
        socket.send(sendPacket);

        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
        socket.receive(receivePacket);

        String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
        System.out.println("Server response: " + response);

        socket.close();
    }
}
