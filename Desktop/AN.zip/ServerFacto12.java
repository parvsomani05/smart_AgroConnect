
// Server.java
import java.net.*;
import java.util.*;

public class ServerFacto12 {
    public static void main(String[] args) {
        try {
            DatagramSocket serverSocket = new DatagramSocket(12345);
            System.out.println("Server is listening on port 12345");

            byte[] receiveBuffer = new byte[1024];
            byte[] sendBuffer;

            while (true) {
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                serverSocket.receive(receivePacket);

                String receivedString = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Received from client: " + receivedString);

                try {
                    // Parse the integer and calculate factorial
                    int number = Integer.parseInt(receivedString);
                    int factorial = calculateFactorial(number);

                    String response = String.valueOf(factorial);
                    sendBuffer = response.getBytes();
                } catch (NumberFormatException e) {
                    String errorResponse = "Invalid input. Please send a valid integer.";
                    sendBuffer = errorResponse.getBytes();
                }

                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();

                DatagramPacket sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, clientAddress, clientPort);
                serverSocket.send(sendPacket);
                System.out.println("Response sent to client.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static int calculateFactorial(int number) {
        int result = 1;
        for (int i = 1; i <= number; i++) {
            result *= i;
        }
        return result;
    }
}

ServerFacto.java
Displaying ServerFacto.java.