// UDP Client
import java.net.*;
import java.io.*;

public class UDPClient15 {
    public static void main(String[] args) throws Exception {
        DatagramSocket clientSocket = new DatagramSocket();
        InetAddress IPAddress = InetAddress.getByName("localhost");
        byte[] sendData = "date".getBytes();
        byte[] receiveData = new byte[1024];
        
        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
        clientSocket.send(sendPacket);

        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
        clientSocket.receive(receivePacket);
        String serverDate = new String(receivePacket.getData(), 0, receivePacket.getLength());
        System.out.println("Current Date from Server: " + serverDate);
        clientSocket.close();
    }
}