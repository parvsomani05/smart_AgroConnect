// UDP Server
import java.net.*;
import java.io.*;

public class UDPServer13 {
    public static void main(String[] args) throws Exception {
        DatagramSocket serverSocket = new DatagramSocket(9876);
        byte[] receiveData = new byte[1024];
        byte[] sendData;

        while (true) {
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            serverSocket.receive(receivePacket);
            String numberStr = new String(receivePacket.getData(), 0, receivePacket.getLength());
            int n = Integer.parseInt(numberStr);
            
            String fibonacciSeries = generateFibonacci(n);
            InetAddress clientAddress = receivePacket.getAddress();
            int clientPort = receivePacket.getPort();
            sendData = fibonacciSeries.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
            serverSocket.send(sendPacket);
        }
    }

    private static String generateFibonacci(int n) {
        StringBuilder series = new StringBuilder();
        int a = 0, b = 1;
        while (a <= n) {
            series.append(a).append(" ");
            int next = a + b;
            a = b;
            b = next;
        }
        return series.toString();
    }
} 